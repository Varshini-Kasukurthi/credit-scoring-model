<!-- 
Readme to help set up the project.
Credit Score Model 
-->
## GET STARTED
  ### Requirements needed to run:
        ~ python 3.*
        ~ pip, If installed, upgrade to the newest pip

        Other Packages Needed:

        ~ pandas
        ~ numpy
        ~ matplotlib
        ~ sklearn


## To run,
    Extract the project in a folder on your machine.
    Note the path of the project folder.
    Open on the terminal, the path of the project folder.
    Run, python main.py


## Conclusion:
    The model can be a a bit far much accurate if done some other function like,
        ~ Apply threshold
        ~ Data resampling
        et-cetera.






